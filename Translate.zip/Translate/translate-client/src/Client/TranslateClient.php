<?php
  namespace App\Client;

  use GuzzleHttp\Client;

  class TranslateClient extends Client
  {
    /**
     * 
     * @return string
     *
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function getData(): string
    {
      $response = $this->request('GET', '/projetTut/ProjetTut/Translate/translate-api/public/index.php/translate-api/trad');

      $newsUrl = (string)$response->getBody();

      return $newsUrl;
    }

    /**
     * @param string $locale $nameApp
     * @return string
     *
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function findTranslate(string $locale, string $nameApp): string
    {
      $response = $this->request('GET', '/projetTut/ProjetTut/Translate/translate-api/public/index.php/translate-api/trad/show?locale=' . $locale . '&nameApp=' . $nameApp);

      $newsUrl = (string)$response->getBody();

      return $newsUrl;
    }

    /**
     * @param string $locale $key_trad $translation $nameApp
     * @return string
     *
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function newTranslate(string $locale, string $key_trad,string $translation, string $nameApp): string
    {
      $response = $this->request('POST', '/projetTut/ProjetTut/Translate/translate-api/public/index.php/translate-api/trad/new?locale=' . $locale . '&key_trad=' . $key_trad . '&translation=' . $translation . '&nameApp=' . $nameApp);

      $newsUrl = (string)$response->getBody();

      return $newsUrl;
    }

    /**
     * @param string $id $locale $key_trad $translation $nameApp
     * @return string
     *
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function editTranslate(string $id, string $locale, string $key_trad,string $translation, string $nameApp): string
    {
      $response = $this->request('PUT', '/projetTut/ProjetTut/Translate/translate-api/public/index.php/translate-api/trad/edit?id=' . $id .'&locale=' . $locale . '&key_trad=' . $key_trad . '&translation=' . $translation . '&nameApp=' . $nameApp);

      $newsUrl = (string)$response->getBody();

      return $newsUrl;
    }

    /**
     * @param string $id
     * @return string
     *
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function deleteTranslate(string $id): string
    {
      $response = $this->request('DELETE', '/projetTut/ProjetTut/Translate/translate-api/public/index.php/translate-api/trad/delete?id=' . $id);

      $newsUrl = (string)$response->getBody();

      return $newsUrl;
    }




  }
