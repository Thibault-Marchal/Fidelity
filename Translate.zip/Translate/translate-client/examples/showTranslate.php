<?php
 use App\Client\TranslateClient;

  require_once __DIR__ . '/../vendor/autoload.php';

  $client = new TranslateClient([
      'base_uri' => 'http://127.0.0.1/'
  ]);
  echo "\n\n";
  echo $client->findTranslate($_GET['locale'], $_GET['nameApp']);//Changer avec POST App
  echo "\n\n";
  //header('Location: http://127.0.0.1/projetTut/ProjetTut/Translate/translate-app/index.php');
