<?php
namespace App\Action;

use App\Manager\Translation;

class ShowTranslate
{
  public function __invoke($params)
  {
    
    $translation = new Translation();
    $dataTranslate = $translation->findTranslate($_GET['locale'], $_GET['nameApp']);

    return $dataTranslate;
  }
}