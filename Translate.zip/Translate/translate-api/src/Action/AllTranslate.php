<?php
namespace App\Action;

use App\Manager\Translation;

class AllTranslate
{
  public function __invoke($params)
  {
    
    $translation = new Translation();
    $dataTranslate = $translation->getData();

    return $dataTranslate;
  }
}