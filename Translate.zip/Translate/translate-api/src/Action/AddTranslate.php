<?php
namespace App\Action;

use App\Manager\Translation;

class AddTranslate
{
  public function __invoke($params)
  {
    
    $translation = new Translation();
    $dataTranslate = $translation->newTranslate($_GET['locale'], $_GET['key_trad'], $_GET['translation'], $_GET['nameApp']);

    return $dataTranslate;
  }
}