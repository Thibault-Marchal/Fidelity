<?php
namespace App\Action;

use App\Manager\Translation;

class EditTranslate
{
  public function __invoke($params)
  {
    
    $translation = new Translation();
    $dataTranslate = $translation->editTranslate($_GET['id'], $_GET['locale'], $_GET['key_trad'], $_GET['translation'], $_GET['nameApp']);

    return $dataTranslate;
  }
}