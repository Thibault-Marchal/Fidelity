<?php
namespace App\Action;

use App\Manager\Translation;

class DeleteTranslate
{
  public function __invoke($params)
  {
    
    $translation = new Translation();
    $dataTranslate = $translation->deleteTranslate($_GET['id']);

    return $dataTranslate;
  }
}