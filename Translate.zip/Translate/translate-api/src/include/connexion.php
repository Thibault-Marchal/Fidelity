<?php
	$host = '127.0.0.1';
	$port = '';
	$dbname = 'microservice';
	$Hostname = 'root';
	$Mdp = '';
	/*
	$host = 'localhost';
	$port = '3306';
	$dbname = 'microservice';
	$Hostname = 'jojo_admin4';
	$Mdp = 'Vknz59#1';*/
	try{
		$bdd = new PDO ("mysql:host=$host;dbname=$dbname;charset=utf8", $Hostname, $Mdp);
		$bdd->exec("SET CHARACTER SET utf8");
		$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch (Exception $e){
		die ('Erreur : ' . $e->getMessage());
	}	

	ini_set('display_error', 0);
	error_reporting(1);							
?>