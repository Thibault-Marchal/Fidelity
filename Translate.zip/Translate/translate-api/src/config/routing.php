<?php
use App\Action\AllTranslate;
use App\Action\AddTranslate;
use App\Action\ShowTranslate;
use App\Action\EditTranslate;
use App\Action\DeleteTranslate;

return [
    [
        'path' => '/translate-api/trad',
        'method' => 'GET',
        'action' => AllTranslate::class
    ],
    [
        'path' => '/translate-api/trad/show',
        'method' => 'GET',
        'action' => ShowTranslate::class
    ],
    [
      'path' => '/translate-api/trad/new',
      'method' => 'POST',
      'action' => AddTranslate::class
    ],
    [
      'path' => '/translate-api/trad/edit',
      'method' => 'PUT',
      'action' => EditTranslate::class
    ],
    [
      'path' => '/translate-api/trad/delete',
      'method' => 'DELETE',
      'action' => DeleteTranslate::class
    ],
];