<?php
namespace App\Manager;
use PDO;

/**
 * Class Translation
 *
 * @package App\Manager
 */
class Translation
{
    protected $id;
    protected $locale;
    protected $key;
    protected $translation;
    protected $application;

    /**
     * Identifier of the translation
     * 
     * @var int
     */
    public function getId(){ 
        return $this->id; 
    }
    public function setId($id){ 
        $this->id = $id; 
    }

    /**
     * Locale of the translation (en_GB, fr_FR, etc...)
     * 
     * @var string
     */
    public function getLocale(){ 
        return $this->locale; 
    }
    public function setLocale($locale){ 
        $this->locale = $locale; 
    }

    /**
     * It represents the key used to fetch the translation (eg 'HELLO')
     * 
     * @var string
     */
    public function getKey(){ 
        return $this->key; 
    }
    public function setKey($key){ 
        $this->key = $key; 
    }
   
    /**
     * It represents the value of the translation for the selected key and locale (eg 'Bonjour' for the key "HELLO" in the locale "fr_FR")
     * 
     * @var string
     */
    public function getTranslation(){ 
        return $this->translation; 
    }
    public function setTranslation($translation){ 
        $this->translation = $translation; 
    }

    /**
     * It represents the name of the application
     * 
     * @var string
     */
    public function getApplication(){ 
        return $this->application; 
    }
    public function setApplication($application){ 
        $this->application = $application; 
    }

    /**
     * 
     * 
     */
    public function getData()
    {
        require './../src/include/connexion.php';
        $reponse = $bdd->query('SELECT * FROM translate'); 
        $data = array(); 
        $i=0; 
        while ($dataTranslate = $reponse->fetch()) 
        { 
            $data["Translater"][$i]["id"] = $dataTranslate["id"]; 
            $data["Translater"][$i]["locale"] = $dataTranslate["locale"]; 
            $data["Translater"][$i]["key_trad"] = $dataTranslate["key_trad"]; 
            $data["Translater"][$i]["translation"] = $dataTranslate["translation"]; 
            $data["Translater"][$i]["nameApp"] = $dataTranslate["nameApp"];
            $i++; 
        } 
        
        if( $reponse == TRUE  ){
            $success = true;
            $msg = 'Les traductions sont bien affichées';
        }
        $reponse->closeCursor(); 

        $array['success'] = $success;
        $array['msg'] = $msg;
        $array['result'] = $data;

        header('Content-Type:Application/json'); 
        echo json_encode($array);
    }

    /**
     * @param string $locale $nameApp
     * 
     */
    public function findTranslate(string $locale, string $nameApp)
    {
        require './../src/include/connexion.php';
        if( !empty($locale) && !empty($nameApp) ){
            $reponse = $bdd->prepare('SELECT * FROM translate WHERE locale = :locale AND nameApp =:nameApp ');
            $reponse->execute(array(
                'locale' => $locale,
                'nameApp' => $nameApp
            )); 
            $data = array(); 
            $i=0; 
            while ($dataTranslate = $reponse->fetch()) 
            { 
                $data["Translater"][$i]["id"] = $dataTranslate["id"]; 
                $data["Translater"][$i]["locale"] = $dataTranslate["locale"]; 
                $data["Translater"][$i]["key_trad"] = $dataTranslate["key_trad"]; 
                $data["Translater"][$i]["translation"] = $dataTranslate["translation"]; 
                $data["Translater"][$i]["nameApp"] = $dataTranslate["nameApp"];
                $i++; 
            } 
            if( $reponse == TRUE ){
                $success = true;
                $msg = "Les traductions de l'application sont bien affichées";
            } else {
                $success = false;
                $msg = "Une erreur s'est produite";
            }
            $reponse->closeCursor(); 
        }else {
            $success = false;
            $msg = "Il manque des informations";
        }

        $array['success'] = $success;
        $array['msg'] = $msg;
        $array['result'] = $data;

        header('Content-Type:Application/json'); 
        echo json_encode($array);
    }


    /**
     * @param string $locale $key_trad $translation $nameApp
     * 
     */
    public function newTranslate(string $locale, string $key_trad, string $translation, string $nameApp)
    {
        require './../src/include/connexion.php';
        if( !empty($locale) && !empty($key_trad) && !empty($translation) && !empty($nameApp) ){
            //Si toutes les données sont saisie par le client
            
            //$reponse = $bdd->prepare('INSERT INTO translate SET locale = :locale, key_trad = :key_trad, translation = :translation, nameApp = :nameApp');

            $reponse = $bdd->prepare('INSERT INTO translate(locale, key_trad, translation, nameApp) VALUE(:locale, :key_trad, :translation, :nameApp)');
            $reponse->execute(array(
                'locale' => $locale,
                'key_trad' => $key_trad,
                'translation' => $translation,
                'nameApp' => $nameApp
            ));
            if( $reponse == TRUE ){
                $success = true;
                $msg = 'La traduction a bien été ajouté';
            } else {
                $success = false;
                $msg = "Une erreur s'est produite";
            }
        }else {
            $success = false;
            $msg = "Il manque des informations";
        } 
            
        $array['success'] = $success;
        $array['msg'] = $msg;

        header('Content-Type:Application/json'); 
        echo json_encode($array);
    }

    /**
     * @param string $id $locale $key_trad $translation $nameApp
     * 
     */
    public function editTranslate(string $id, string $locale, string $key_trad, string $translation, string $nameApp)
    {
        require './../src/include/connexion.php';
        if( !empty($id) && !empty($locale) && !empty($key_trad) && !empty($translation) && !empty($nameApp) ){
            //Si toutes les données sont saisie par le client
            $reponse = $bdd->prepare('UPDATE translate SET locale =:locale, key_trad=:key_trad, translation=:translation, nameApp=:nameApp WHERE id=:id');
            $reponse->execute(array(
                'locale' => $locale,
                'key_trad' => $key_trad,
                'translation' => $translation,
                'nameApp' => $nameApp,
                'id' => $id
            )); 
            if( $reponse == TRUE  ){
                $success = true;
                $msg = 'La traduction a bien été modifié';
            } else {
                $success = false;
                $msg = "Une erreur s'est produite";
            }
        }else {
            $success = false;
            $msg = "Il manque des informations";
        }
        $array['success'] = $success;
        $array['msg'] = $msg;

        header('Content-Type:Application/json'); 
        echo json_encode($array);
    }

    /**
     * @param string $id
     * 
     */
    public function deleteTranslate(string $id)
    {
        require './../src/include/connexion.php';
        if( !empty($id) ){
            //Si toutes les données sont saisie par le client
            $reponse = $bdd->prepare('DELETE FROM translate WHERE id=:id');
            $reponse->execute(array(
                'id' => $id
            )); 
            if( $reponse == TRUE  ){
                $success = true;
                $msg = 'La traduction a bien été supprimé';
            } else {
                $success = false;
                $msg = "Une erreur s'est produite";
            }
        }else {
            $success = false;
            $msg = "Il manque des informations";
        }
        $array['success'] = $success;
        $array['msg'] = $msg;

        header('Content-Type:Application/json'); 
        echo json_encode($array);
    }

}