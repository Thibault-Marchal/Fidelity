<?php
	require('../connexionBDD.php');

	$input = filter_input_array(INPUT_POST);

	if ($input['action'] == 'edit') 
	{	

		$req = $bdd->prepare('UPDATE translate SET 
		locale = :locale, 
		keyTranslation = :keyTranslation, 
		translation = :translation, 
		application = :application
		WHERE ID='.$input['ID'].';');
		
		$req -> execute(array(
		'locale' => $input['locale'], 
		'keyTranslation' => $input['keyTranslation'], 
		'translation' => $input['translation'],
		'application' => $input['application']));

		header('Location:../index.php');
	}
	else if ($input['action'] == 'delete') 
	{	
		$sql = 'DELETE FROM translate WHERE ID='.$input['ID'].';';
		
		$bdd->exec($sql);
	}