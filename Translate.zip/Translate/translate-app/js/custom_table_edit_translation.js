$(document).ready(function(){
	$('#data_table_translation').Tabledit({
		deleteButton: true,
		editButton: true,   			
		columns: {
		  identifier: [0, 'ID'],
		  editable: [[1, 'locale'], [2, 'keyTranslation'], [3, 'translation'],[4, 'application']]
		},
		hideIdentifier: true,
		url: 'edit/live_edit_translation.php'	
	});
});