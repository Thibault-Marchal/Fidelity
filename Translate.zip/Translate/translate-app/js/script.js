function genTabData(response){
  var translate = response.data.result.Translater; 
  var translateData = document.getElementById('dataTranslate'); 
  var id =0;
  const parent = document.getElementById("dataTranslate");
  while (parent.firstChild) {
    parent.firstChild.remove();
  }
  
  for (var i = 0; i < translate.length; i++) { 
    var translateRow = document.createElement('tr'); 
    var locale = document.createElement('td'); 
    var key_trad = document.createElement('td'); 
    var translation = document.createElement('td'); 
    var nameApp = document.createElement('td'); 
    var caseEdit = document.createElement('td'); 
    var caseDelete  = document.createElement('td'); 
    var linkEdit = document.createElement('a'); 
    var linkDel = document.createElement('a'); 
    var btn_modif = document.createElement("button"); 
    var btn_delete = document.createElement("BUTTON"); 

    btn_modif.className = "btn btn-warning"; 
    btn_modif.innerHTML = "Modifier";
    
    btn_delete.className = "btn btn-danger"; 
    btn_delete.innerHTML = "Supprimer"; 

    locale.textContent = translate[i].locale; 
    key_trad.textContent = translate[i].key_trad; 
    translation.textContent = translate[i].translation; 
    nameApp.textContent = translate[i].nameApp; 

    linkEdit.textContent = "Modifier"; 
    linkEdit.className = "btn btn-warning"; 
    linkEdit.setAttribute("value", i); 
    linkEdit.setAttribute("data-toggle", "modal"); 
    linkEdit.setAttribute("data-target", "#modifTranslation"); 
    
    linkEdit.addEventListener("click", function(){
        var id=$(this).attr('value');
        $(".modal-body #id-modif").val(translate[id].id); 
        $(".modal-body #locale-modif").val(translate[id].locale); 
        $(".modal-body #key-modif").val(translate[id].key_trad); 
        $(".modal-body #translation-modif").val(translate[id].translation); 
        $(".modal-body #nameApp-modif").val(translate[id].nameApp);
    });

    linkDel.textContent = "Supprimer"; 
    linkDel.className = "btn btn-danger"; 
    linkDel.setAttribute("value", i); 
    linkDel.setAttribute("data-toggle", "modal"); 
    linkDel.setAttribute("data-target", "#deleteTranslation"); 

    linkDel.addEventListener("click", function(){
        var id=$(this).attr('value');
        $(".modal-body #id-delete").val(translate[id].id); 
        $(".modal-body #locale-delete").val(translate[id].locale); 
        $(".modal-body #key-delete").val(translate[id].key_trad); 
        $(".modal-body #translation-delete").val(translate[id].translation); 
        $(".modal-body #nameApp-delete").val(translate[id].nameApp);
    });

    translateData.appendChild(translateRow); 
    translateRow.appendChild(locale); 
    translateRow.appendChild(key_trad); 
    translateRow.appendChild(translation); 
    translateRow.appendChild(nameApp); 
    translateRow.appendChild(caseEdit); 
    caseEdit.appendChild(linkEdit); 
    translateRow.appendChild(caseDelete); 
    caseDelete.appendChild(linkDel); 
  }
}

function getTranslate(){ 
  // Request get all trad 
  axios.get('/projetTut/ProjetTut/Translate/translate-api/public/index.php/translate-api/trad') 
    .then(function (response) { 
      // handle success 
      genTabData(response);
          
    }) 
    .catch(function (error) { 
      // handle error 
      console.log(error); 
  }); 
} 

function showTranslate(){ 
  // Request get trad with locale and nameApp 
  var search = $('#formSearchTranslate').serialize();
  axios.get('/projetTut/ProjetTut/Translate/translate-api/public/index.php/translate-api/trad/show?'+ search) 
    .then(function (response) { 
      // handle success 
      genTabData(response);  
    }) 
    .catch(function (error) { 
      // handle error 
      console.log(error); 
      alert("traductions non disponibles");
  }); 
} 