<!DOCTYPE html> 
<html lang="fr"> 
    <head> 
        <title></title> 
        <meta charset="utf-8"> 
        <!-- Bootstrap CSS --> 
        <link rel="stylesheet" href="css/bootstrap-theme.min.css"> 
        <link rel="stylesheet" href="css/bootstrap(3.3.5).min.css"> 
 
        <!-- font awesome --> 
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css"> 
 
        <!-- jQuery --> 
        <script src="js/jquery.min.js"></script> 
        <script src="js/bootstrap.min.js"></script> 
    </head> 
    <body> 
 
        <!-- Normalement il faut pas utiliser le cdn mais importer via les nodes modules --> 
        <!-- doc pour import  https://www.npmjs.com/package/axios  --> 
        <script src="https://unpkg.com/axios/dist/axios.min.js"></script> 
        <script src="./node_modules/axios/dist/axios.min.js"></script>
        <script> 
            


            function getTranslate(){ 
                // Request get all trad 
                //import axios from './axios.js'; 
                axios.get('/projettut/Translate/translate-api/public/index.php/translate-api/trad') 
                    .then(function (response) { 
                        // handle success 
                        console.log(response); //Pour récupérer toutes les infos de connexion 
                        //console.log(response.data.result.Translater); // Récupère uniquement les traductions 
                        var translate = response.data.result.Translater; 
                        var translateData = document.getElementById('dataTranslate'); 
                        var id =0;
                      
                        for (var i = 0; i < translate.length; i++) { 
                            var translateRow = document.createElement('tr'); 
                            var locale = document.createElement('td'); 
                            var key_trad = document.createElement('td'); 
                            var translation = document.createElement('td'); 
                            var nameApp = document.createElement('td'); 
                            var caseEdit = document.createElement('td'); 
                            var caseDelete  = document.createElement('td'); 
                            var linkEdit = document.createElement('a'); 
                            var linkDel = document.createElement('a'); 
                            var btn_modif = document.createElement("button"); 
                            var btn_delete = document.createElement("BUTTON"); 
 
                            btn_modif.className = "btn btn-warning"; 
                            btn_modif.innerHTML = "Modifier";
                            

                            btn_delete.className = "btn btn-danger"; 
                            btn_delete.innerHTML = "Supprimer"; 
 
                            locale.textContent = translate[i].locale; 
                            key_trad.textContent = translate[i].key_trad; 
                            translation.textContent = translate[i].translation; 
                            nameApp.textContent = translate[i].nameApp; 
 
                            linkEdit.textContent = "Modifier"; 
                            linkEdit.className = "btn btn-warning"; 
                            linkEdit.setAttribute("value", i); 
                            linkEdit.setAttribute("data-toggle", "modal"); 
                            linkEdit.setAttribute("data-target", "#modifTranslation"); 
                            
                            linkEdit.addEventListener("click", function(){
                              var id=$(this).attr('value');
                              $(".modal-body #id-modif").val(translate[id].id); 
                              $(".modal-body #locale-modif").val(translate[id].locale); 
                              $(".modal-body #key-modif").val(translate[id].key_trad); 
                              $(".modal-body #translation-modif").val(translate[id].translation); 
                              $(".modal-body #nameApp-modif").val(translate[id].nameApp);
                            });
                        
                            linkDel.textContent = "Supprimer"; 
                            linkDel.className = "btn btn-danger"; 
                            linkDel.setAttribute("value", i); 
                            linkDel.setAttribute("data-toggle", "modal"); 
                            linkDel.setAttribute("data-target", "#deleteTranslation"); 

                            linkDel.addEventListener("click", function(){
                              var id=$(this).attr('value');
                              $(".modal-body #id-delete").val(translate[id].id); 
                              $(".modal-body #locale-delete").val(translate[id].locale); 
                              $(".modal-body #key-delete").val(translate[id].key_trad); 
                              $(".modal-body #translation-delete").val(translate[id].translation); 
                              $(".modal-body #nameApp-delete").val(translate[id].nameApp);
                            });
 
                            translateData.appendChild(translateRow); 
                            translateRow.appendChild(locale); 
                            translateRow.appendChild(key_trad); 
                            translateRow.appendChild(translation); 
                            translateRow.appendChild(nameApp); 
                            translateRow.appendChild(caseEdit); 
                            caseEdit.appendChild(linkEdit); 
                            translateRow.appendChild(caseDelete); 
                            caseDelete.appendChild(linkDel); 
                            
                        } 
                          
                    }) 
                    .catch(function (error) { 
                        // handle error 
                        console.log(error); 
                    }); 
            } 
 
        </script> 
        <div class="table"> 
            <table class="table table-striped"> 
                <thead> 
                <tr> 
                    <th>locale</th> 
                    <th>key_trad</th> 
                    <th>translation</th> 
                    <th>nameApp</th> 
                    <th></th> 
                    <th></th> 
                </tr> 
                </thead> 
                <tbody id="dataTranslate"> 
                <script>getTranslate();</script> 
                </tbody> 
            </table> 
        </div> 
 
        <!-- bouton de lancement du modal d'ajout --> 
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addTranslation">Ajouter une traduction</button> 
 
        <!--Ajout d'une traduction --> 
        <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="addTranslation"> 
            <div class="modal-dialog modal-lg"> 
                <div class="modal-content"> 
                    <div class="modal-header"> 
                        <h5 class="modal-title" id="exampleModalLabel">Ajouter une traduction</h5> 
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> 
                            <span aria-hidden="true">&times;</span> 
                        </button> 
                    </div> 
                    <div class="modal-body"> 
                        <form method="post" id="formAddTranslate" action="../translate-client/examples/addTranslate.php"> 
                            <div class="form-group"> 
                                <label for="recipient-name" class="col-form-label">Locale : <br>(Ex : fr_FR)</label> 
                                <input type="text" class="form-control" id="recipient-name" name="locale"> 
                            </div> 
                            <div class="form-group"> 
                                <label for="message-text" class="col-form-label">Clé de traduction :</label> 
                                <input type="text" class="form-control" id="recipient-name" name="key_trad"> 
                            </div> 
                            <div class="form-group"> 
                                <label for="message-text" class="col-form-label">Traduction :</label> 
                                <input type="text" class="form-control" id="recipient-name" name="translation"> 
                            </div> 
                            <div class="form-group"> 
                                <label for="message-text" class="col-form-label">Application :</label> 
                                <input type="text" class="form-control" id="recipient-name" name="nameApp"> 
                            </div> 
                        </form> 
                    </div> 
                    <div class="modal-footer"> 
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button> 
                        <button type="submit" class="btn btn-primary" form="formAddTranslate">Sauvegarder</button> 
                    </div> 
                </div> 
            </div> 
        </div> 
 
        <!--Modification d'une traduction --> 
        <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="modifTranslation"> 
            <div class="modal-dialog modal-lg"> 
                <div class="modal-content"> 
                    <div class="modal-header"> 
                        <h5 class="modal-title" id="exampleModalLabel">Modifier une traduction</h5> 
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> 
                            <span aria-hidden="true">&times;</span> 
                        </button> 
                    </div> 
                    <div class="modal-body"> 
                        <form id="formModifTranslate" action="../translate-client/examples/editTranslate.php"> 
                            <div class="form-group" style="display:none"> 
                                <input type="text" class="form-control" id="id-modif" name="id" value=> 
                            </div> 
                            <div class="form-group"> 
                                <label for="locale-modif" class="col-form-label">Locale : <br>(Ex : fr_FR)</label> 
                                <input type="text" class="form-control" id="locale-modif" name="locale"> 
                            </div> 
                            <div class="form-group"> 
                                <label for="key-modif" class="col-form-label">Clé de traduction :</label> 
                                <input type="text" class="form-control" id="key-modif" name="key_trad"> 
                            </div> 
                            <div class="form-group"> 
                                <label for="translate-modif" class="col-form-label">Traduction :</label> 
                                <input type="text" class="form-control" id="translation-modif" name="translation"> 
                            </div> 
                            <div class="form-group"> 
                                <label for="nameApp-modif" class="col-form-label">Application :</label> 
                                <input type="text" class="form-control" id="nameApp-modif" name="nameApp"> 
                            </div> 
                        </form> 
                    </div> 
                    <div class="modal-footer"> 
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button> 
                        <button type="submit" class="btn btn-primary" form="formModifTranslate">Modifier</button> 
                    </div> 
                </div> 
            </div> 
        </div> 
 
        <!--Suppression d'une traduction --> 
        <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="deleteTranslation"> 
            <div class="modal-dialog modal-lg"> 
                <div class="modal-content"> 
                    <div class="modal-header"> 
                        <h5 class="modal-title" id="exampleModalLabel">Etes-vous sûr de vouloir supprimer cette traduction ?</h5> 
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> 
                            <span aria-hidden="true">&times;</span> 
                        </button> 
                    </div> 
                    <div class="modal-body"> 
                        <form method="get" id="formDeleteTranslate" action="../translate-client/examples/deleteTranslate.php"> 
                            <div class="form-group"> 
                                <label for="recipient-name" class="col-form-label">Locale : <br>(Ex : fr_FR)</label> 
                                <input type="text" class="form-control" id="locale-delete" name="locale" readonly> 
                            </div> 
                            <div class="form-group"> 
                                <label for="message-text" class="col-form-label">Clé de traduction :</label> 
                                <input type="text" class="form-control" id="key-delete" name="key_trad" readonly> 
                            </div> 
                            <div class="form-group"> 
                                <label for="message-text" class="col-form-label">Traduction :</label> 
                                <input type="text" class="form-control" id="translation-delete" name="translation" readonly> 
                            </div> 
                            <div class="form-group"> 
                                <label for="message-text" class="col-form-label">Application :</label> 
                                <input type="text" class="form-control" id="nameApp-delete" name="nameApp" readonly> 
                            </div> 
                        </form> 
                    </div> 
                    <div class="modal-footer"> 
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button> 
                        <button type="submit" class="btn btn-primary" form="formAddTranslate">Supprimer</button> 
                    </div> 
                </div> 
            </div> 
        </div> 
    </body> 
</html> 
