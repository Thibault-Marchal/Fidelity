<!DOCTYPE html> 
<html lang="fr"> 
    <head> 
        <title></title> 
        <meta charset="utf-8"> 
        <!-- Bootstrap CSS --> 
        <link rel="stylesheet" href="css/bootstrap-theme.min.css"> 
        <link rel="stylesheet" href="css/bootstrap(3.3.5).min.css"> 
 
        <!-- font awesome --> 
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css"> 
        <link rel="stylesheet" href="css/style.css"> 
 
        <!-- jQuery --> 
        <script src="js/jquery.min.js"></script> 
        <script src="js/bootstrap.min.js"></script> 
    </head> 
    <body> 

        <script src="./node_modules/axios/dist/axios.min.js"></script>
        <script src="./js/script.js"></script> 
        <div class="table"> 
            <table class="table table-striped"> 
                <thead> 
                <tr> 
                    <th>locale</th> 
                    <th>key_trad</th> 
                    <th>translation</th> 
                    <th>nameApp</th> 
                    <th></th> 
                    <th></th> 
                </tr> 
                </thead> 
                <tbody id="dataTranslate"> 
                </tbody> 
            </table> 
        </div> 

        <button type="button" id="btnAllTrad" class="btn btn-primary" onclick="getTranslate()">Toutes traductions</button>     
     
 
        <form name="form"  id="formSearchTranslate" > 
            <div class="form-group"> 
                <label for="recipient-name" class="col-form-label">Locale : <br>(Ex : fr_FR)</label> 
                <input type="text" class="form-control" id="localeSearch" name="locale"> 
            </div> 
            <div class="form-group"> 
                <label for="message-text" class="col-form-label">Application :</label> 
                <input type="text" class="form-control" id="appSearch" name="nameApp"> 
            </div> 
            <button type="button" class="btn btn-primary" form="formSearchTranslate" onclick="showTranslate()">Recherche</button> 
        </form> 

        <!-- bouton de lancement du modal d'ajout --> 
        <button type="button" id="btnAddTrad" class="btn btn-primary" data-toggle="modal" data-target="#addTranslation">Ajouter une traduction</button> 
       

        <!--Ajout d'une traduction --> 
        <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="addTranslation"> 
            <div class="modal-dialog modal-lg"> 
                <div class="modal-content"> 
                    <div class="modal-header"> 
                        <h5 class="modal-title" id="exampleModalLabel">Ajouter une traduction</h5> 
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> 
                            <span aria-hidden="true">&times;</span> 
                        </button> 
                    </div> 
                    <div class="modal-body"> 
                        <form method="post" id="formAddTranslate" action="../translate-client/examples/addTranslate.php"> 
                            <div class="form-group"> 
                                <label for="recipient-name" class="col-form-label">Locale : <br>(Ex : fr_FR)</label> 
                                <input type="text" class="form-control" id="recipient-name" name="locale"> 
                            </div> 
                            <div class="form-group"> 
                                <label for="message-text" class="col-form-label">Clé de traduction :</label> 
                                <input type="text" class="form-control" id="recipient-name" name="key_trad"> 
                            </div> 
                            <div class="form-group"> 
                                <label for="message-text" class="col-form-label">Traduction :</label> 
                                <input type="text" class="form-control" id="recipient-name" name="translation"> 
                            </div> 
                            <div class="form-group"> 
                                <label for="message-text" class="col-form-label">Application :</label> 
                                <input type="text" class="form-control" id="recipient-name" name="nameApp"> 
                            </div> 
                        </form> 
                    </div> 
                    <div class="modal-footer"> 
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button> 
                        <button type="submit" class="btn btn-primary" form="formAddTranslate">Sauvegarder</button> 
                    </div> 
                </div> 
            </div> 
        </div> 
 
        <!--Modification d'une traduction --> 
        <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="modifTranslation"> 
            <div class="modal-dialog modal-lg"> 
                <div class="modal-content"> 
                    <div class="modal-header"> 
                        <h5 class="modal-title" id="exampleModalLabel">Modifier une traduction</h5> 
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> 
                            <span aria-hidden="true">&times;</span> 
                        </button> 
                    </div> 
                    <div class="modal-body"> 
                        <form id="formModifTranslate" action="../translate-client/examples/editTranslate.php"> 
                            <div class="form-group" style="display:none"> 
                                <input type="text" class="form-control" id="id-modif" name="id" value=> 
                            </div> 
                            <div class="form-group"> 
                                <label for="locale-modif" class="col-form-label">Locale : <br>(Ex : fr_FR)</label> 
                                <input type="text" class="form-control" id="locale-modif" name="locale"> 
                            </div> 
                            <div class="form-group"> 
                                <label for="key-modif" class="col-form-label">Clé de traduction :</label> 
                                <input type="text" class="form-control" id="key-modif" name="key_trad"> 
                            </div> 
                            <div class="form-group"> 
                                <label for="translate-modif" class="col-form-label">Traduction :</label> 
                                <input type="text" class="form-control" id="translation-modif" name="translation"> 
                            </div> 
                            <div class="form-group"> 
                                <label for="nameApp-modif" class="col-form-label">Application :</label> 
                                <input type="text" class="form-control" id="nameApp-modif" name="nameApp"> 
                            </div> 
                        </form> 
                    </div> 
                    <div class="modal-footer"> 
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button> 
                        <button type="submit" class="btn btn-primary" form="formModifTranslate">Modifier</button> 
                    </div> 
                </div> 
            </div> 
        </div> 
 
        <!--Suppression d'une traduction --> 
        <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="deleteTranslation"> 
            <div class="modal-dialog modal-lg"> 
                <div class="modal-content"> 
                    <div class="modal-header"> 
                        <h5 class="modal-title" id="exampleModalLabel">Etes-vous sûr de vouloir supprimer cette traduction ?</h5> 
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> 
                            <span aria-hidden="true">&times;</span> 
                        </button> 
                    </div> 
                    <div class="modal-body"> 
                        <form id="formDeleteTranslate" action="../translate-client/examples/deleteTranslate.php"> 
														<div class="form-group" style="display:none"> 
                                <input type="text" class="form-control" id="id-delete" name="id" value=> 
                            </div> 
                            <div class="form-group"> 
                                <label for="recipient-name" class="col-form-label">Locale : <br>(Ex : fr_FR)</label> 
                                <input type="text" class="form-control" id="locale-delete" name="locale" readonly> 
                            </div> 
                            <div class="form-group"> 
                                <label for="message-text" class="col-form-label">Clé de traduction :</label> 
                                <input type="text" class="form-control" id="key-delete" name="key_trad" readonly> 
                            </div> 
                            <div class="form-group"> 
                                <label for="message-text" class="col-form-label">Traduction :</label> 
                                <input type="text" class="form-control" id="translation-delete" name="translation" readonly> 
                            </div> 
                            <div class="form-group"> 
                                <label for="message-text" class="col-form-label">Application :</label> 
                                <input type="text" class="form-control" id="nameApp-delete" name="nameApp" readonly> 
                            </div> 
                        </form> 
                    </div> 
                    <div class="modal-footer"> 
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button> 
                        <button type="submit" class="btn btn-primary" form="formDeleteTranslate">Supprimer</button> 
                    </div> 
                </div> 
            </div> 
        </div> 
    </body> 
</html> 
