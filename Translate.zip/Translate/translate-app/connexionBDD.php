<?php
	$host = 'localhost';
	$Port = '';
	$dbname = 'projettut';
	$Hostname = 'root';
	$Mdp = '';

	try
	{
		$bdd = new PDO ("mysql:host=$host;dbname=$dbname;charset=utf8", $Hostname, $Mdp);
		// , array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
	}
	catch (Exception $e)
	{
		die ('Erreur : ' . $e->getMessage());
	}								
?>