<?php
    //require ('connexionBDD.php');
    //use Translate\Client\TranslateClient;

?>
<!DOCTYPE html>
<html lang="fr">
	<head>
		<title></title>
		<meta charset="utf-8">
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="css/bootstrap-theme.min.css">
		<link rel="stylesheet" href="css/bootstrap(3.3.5).min.css">

		<!-- font awesome -->
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">

		<!-- jQuery -->
		<script src="js/jquery.min.js"></script>

		<script src="js/bootstrap.min.js"></script>

		<!-- TableEdit -->
		<script type="text/javascript" src="js/jquery.tabledit.js"></script>
		<script type="text/javascript" src="js/custom_table_edit_translation.js"></script>

		<!-- Pagination
		<script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
		-->

		<!-- Normalement il faut pas utiliser le cdn mais importer via les nodes modules -->
	<!-- doc pour import  https://www.npmjs.com/package/axios  -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.19.0/axios.min.js" integrity="sha256-S1J4GVHHDMiirir9qsXWc8ZWw74PHHafpsHp5PXtjTs=" crossorigin="anonymous"></script>
	<script src="./node_modules/axios/dist/axios.min.js"></script>	
</head>
	<body>

	
	<script>
		

	function getTranslate(){
		// Request get all trad
		//import axios from './axios.js';
		axios.get('/projettut/Translate/translate-api/public/index.php/translate-api/trad')
			.then(function (response) {
				// handle success
				console.log(response); //Pour récupérer toutes les infos de connexion
				//console.log(response.data.result.Translater); // Récupère uniquement les traductions

				var translate = response.data.result.Translater;
				var translateData = document.getElementById('dataTranslate');
				for (var i = 0; i < translate.length; i++) {
					var translateRow = document.createElement('tr');
					var locale = document.createElement('td');
					var key_trad = document.createElement('td');
					var translation = document.createElement('td');
					var nameApp = document.createElement('td');
					var id = document.createElement('td');
					var linkEdit = document.createElement('a');
					var linkDel = document.createElement('a');
			
					locale.textContent = translate[i].locale;
					key_trad.textContent = translate[i].key_trad;
					translation.textContent = translate[i].translation;
					nameApp.textContent = translate[i].nameApp;

					linkEdit.textContent = "Modifier"
					linkEdit.href = '../translate-client/examples/editTranslate.php?id=translate[i].id';
					linkDel.textContent = "X"
					linkDel.style = "margin:50px"
					linkDel.href = '../translate-client/examples/deleteTranslate.php?id='+translate[i].id;

					translateData.appendChild(translateRow);
					translateRow.appendChild(locale);
					translateRow.appendChild(key_trad);
					translateRow.appendChild(translation);
					translateRow.appendChild(nameApp);
					translateRow.appendChild(id);
					id.appendChild(linkEdit);
					id.appendChild(linkDel);
			
				}
			})
			.catch(function (error) {
				// handle error
				console.log(error);
			});
		}	


	</script>

		
		<div class="table">
			<table id="data_table_translation" class="table table-striped">
				<thead>
					<tr>
						<th>ID</th>
						<th>locale</th>
						<th>keyTranslation</th>
						<th>translation</th>
						<th>application</th>
						<th>Modification / Suppression</th>
					</tr>
				</thead>
				<tbody id="dataTranslate">
					<script>getTranslate();</script>
					
				</tbody>
			</table>
		</div>

        <!-- bouton de lancement du modal -->
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-lg">Ajouter une traduction</button>

        <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ajouter une traduction</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="post" id="formAddTranslate" action="../translate-client/examples/addTranslate.php" >
                            <div class="form-group">
                                <label for="recipient-name" class="col-form-label">Locale : <br>(Ex : fr_FR)</label>
                                <input type="text" class="form-control" id="recipient-name" name="locale">
                            </div>
                            <div class="form-group">
                                <label for="message-text" class="col-form-label">Clé de traduction :</label>
                                <input type="text" class="form-control" id="recipient-name" name="key_trad">
                            </div>
                            <div class="form-group">
                                <label for="message-text" class="col-form-label">Traduction :</label>
                                <input type="text" class="form-control" id="recipient-name" name="translation">
                            </div>
                            <div class="form-group">
                                <label for="message-text" class="col-form-label">Application :</label>
                                <input type="text" class="form-control" id="recipient-name" name="nameApp">
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary" form="formAddTranslate" >Sauvegarder</button>
                    </div>
                </div>
            </div>
        </div>
	</body>
</html>