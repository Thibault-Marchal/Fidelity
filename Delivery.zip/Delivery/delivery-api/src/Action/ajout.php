<?php

include '../include/header.php';

if(!empty($_POST["parcel_number"]) && !empty($_POST["latitude"]) && !empty($_POST["longitude"]) && !empty($_POST["date"]) && !empty($_POST["heure"]))
{

  if( intval($_POST["parcel_number"] > 0))
  {
    if( intval($_POST["latitude"] > 0) || intval($_POST["latitude"] <= 0))
    {
      if( intval($_POST["longitude"] > 0) || intval($_POST["longitude"] <= 0))
      {

        $requete = $pdo->prepare("INSERT INTO `delivery` (`id`, `parcel_number`, `latitude`, `longitude`, `date`, `heure`) VALUES (NULL,
        :parcel, :latitude, :longitude, :date, :heure);");
        $requete->bindParam(':parcel', $_POST["parcel_number"]);
        $requete->bindParam(':latitude', $_POST["latitude"]);
        $requete->bindParam(':longitude', $_POST["longitude"]);
        $requete->bindParam(':date', $_POST["date"]);
        $requete->bindParam(':heure', $_POST["heure"]);
        $requete->execute();

        $retour["success"] = true;
        $retour["message"] = "Point de livraison ajouté";
        $retour["results"] = array();


      } else {
        $retour["success"] = false;
        $retour["message"] = "longitude incorrect";
      }

    } else {
    $retour["success"] = false;
    $retour["message"] = "latitude incorrect";
    }

  } else {
    $retour["success"] = false;
    $retour["message"] = "parcel number incorrect";
  }
} else {
  $retour["success"] = false;
  $retour["message"] = "Il manque des infos";
}



echo json_encode($retour);
