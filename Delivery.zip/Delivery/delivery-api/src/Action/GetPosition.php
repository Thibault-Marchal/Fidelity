<?php
namespace App\Action;

use App\Manager\Position;

class GetPosition
{
  public function __invoke($params)
  {
    $position = new Position();
    $dataDelivery = $position->getPosition($_GET['parcel_number']);

    return $dataDelivery;
  }
}