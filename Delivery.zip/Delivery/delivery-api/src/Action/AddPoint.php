<?php
namespace App\Action;

use App\Manager\Position;

class AddPoint
{
  public function __invoke($params)
  {
    $position = new Position();
    $dataDelivery = $position->addPoint($_GET['parcel_number'], $_GET['latitude'], $_GET['longitude'], $_GET['date'], $_GET['heure']);
    print_r($_GET);
    return $dataDelivery;
  }
}