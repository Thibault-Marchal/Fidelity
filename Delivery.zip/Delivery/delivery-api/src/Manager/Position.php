<?php
namespace App\Manager;
use PDO;

/**
 * Class Position
 *
 * @package App\Manager
 */
class Position
{
	protected $id;
	protected $parcelNumber;
	protected $latitude;
	protected $longitude;
	protected $date;

	public function getId(){ 
		return $this->id; 
	}

	public function setId($id){ 
		$this->id = $id; 
	}

	public function getParcelNumber(){ 
		return $this->parcelNumber; 
	}

	public function setParcelNumber($parcelNumber){ 
		$this->parcelNumber = $parcelNumber; 
	}

	public function getLatitude(){ 
		return $this->latitude; 
	}

	public function setLatitude($latitude){ 
		$this->latitude = $latitude; 
	}

	public function getLongitude(){ 
		return $this->longitude; 
	}

	public function setLongitude($longitude){ 
		$this->longitude = $longitude; 
	}

	public function getDate(){ 
		return $this->date; 
	}

	public function setDate($date){ 
		$this->date = $date; 
	}


	public function addPoint(int $parcel_number, float $latitude, float $longitude, string $date, string $heure)
	{
		require './../src/include/connexion.php';

		if(!empty($parcel_number) && !empty($latitude) && !empty($longitude) && !empty($date) && !empty($heure)){

			if(is_int($parcel_number)){
				if(is_float($latitude)){
					if(is_float($longitude)){
						if(date_create_from_format('Y-m-d', $date)){
							if(date_create_from_format("H:i",$heure)){
								if($parcel_number > 0){

                                	// On vérifie si le numéro de colis existe
									$colisExist = $bdd->prepare('SELECT COUNT(*) AS colisExist FROM delivery WHERE parcel_number = :parcel_number');
									$colisExist->execute(array(
										'parcel_number' => $parcel_number));
									$dataColis = $colisExist->fetch(); 

                               		// Si le colis existe, modifie juste les coordonées
									if (($dataColis['colisExist'] == 1)){
										$updateColis = $bdd->prepare('UPDATE delivery SET latitude = :latitude , longitude = :longitude WHERE parcel_number =:parcel_number');
										$updateColis->bindParam(':latitude', $latitude);
										$updateColis->bindParam(':longitude', $longitude);
										$updateColis->bindParam(':parcel_number', $parcel_number);

										if($updateColis->execute() ){
											$success = true;
											$msg = 'Coordonées du colis modifiés';
										}else{
											$success = false;
											$msg = "Une erreur s'est produite";
										}
										$updateColis->closeCursor();
									}else{
                                    	// Si il n'existe pas, on l'insère dans la bdd
										$addColis = $bdd->prepare('INSERT INTO delivery (parcel_number, latitude, longitude, date, heure) VALUES (:parcel_number, :latitude, :longitude, :date, :heure)');
										$addColis->bindParam(':parcel_number', $parcel_number);
										$addColis->bindParam(':latitude', $latitude);
										$addColis->bindParam(':longitude', $longitude);
										$addColis->bindParam(':date', $date);
										$addColis->bindParam(':heure', $heure);

										if($addColis->execute()){
											$success = true;
											$msg = 'Colis ajouté';
										}else{
											$success = false;
											$msg = "Une erreur s'est produite";
										}
										$addColis->closeCursor();
									}
								}else{
									$success = false;
									$msg = "Numéro de colis invalide. (Il doit être supérieur à 0)";
								}
							}else{
								$success = false;
								$msg = "Format de l'heure incorrecte. (Heure:Minute)";
							}
						}else{
							$success = false;
							$msg = "Format de la date incorrecte. (Année-Mois-Jour)";

						}
					}else{
						$success = false;
						$msg = "La longitude est incorrecte. (Nombre décimal obligatoire)";
					}
				}else{
					$success = false;
					$msg = "La latitude est incorrecte. (Nombre décimal obligatoire)";
				}
			}else{
				$success = false;
				$msg = "Le numéro de colis est incorrect. (Nombre entier obligatoire)";
			}
		}else{
			$success = false;
			$msg = "Il manque des informations";
		}

		$array['success'] = $success;
		$array['msg'] = $msg;

		header('Content-Type:Application/json'); 
		echo json_encode($array);
	}

	public function getPosition(string $parcelNumber)
	{
		require './../src/include/connexion.php';

		if(!empty($parcelNumber)){
			// on affiche tout les colis
			if($parcelNumber == 'all'){
				$getAllColis = $bdd->prepare("SELECT * FROM delivery");
				$getAllColis->execute();

				$i = 0;
				while($AllColis = $getAllColis->fetch()){
					$data["Colis"][$i]["parcel_number"] = $AllColis['parcel_number'];
					$data["Colis"][$i]["latitude"] = $AllColis['latitude'];
					$data["Colis"][$i]["longitude"] = $AllColis['longitude'];
					$data["Colis"][$i]["date"] = $AllColis['date'];
					$data["Colis"][$i]["heure"] = $AllColis['heure'];
					$success = true;
					$msg = "";
					$i++;
				}
			}else{
				// On vérifie si le numéro de colis existe
				$colisExist = $bdd->prepare('SELECT COUNT(*) AS colisExist FROM delivery WHERE parcel_number = :parcel_number');
				$colisExist->execute(array(
					'parcel_number' => $parcelNumber)); 
				$dataColis = $colisExist->fetch(); 

                	// Si le colis existe on récupère tout
				if (($dataColis['colisExist'] == 1)){
					$getColis = $bdd->prepare('SELECT * FROM delivery WHERE parcel_number = :parcel_number');
					$getColis->execute(array(
						'parcel_number' => $parcelNumber)); 

					$dataDelivery = $getColis->fetch(); 
					$getColis->closeCursor();

					$data["Colis"]["id"] = $dataDelivery["id"];
					$data["Colis"]["parcel_number"] = $dataDelivery["parcel_number"];
					$data["Colis"]["latitude"] = $dataDelivery["latitude"];
					$data["Colis"]["longitude"] = $dataDelivery["longitude"];
					$data["Colis"]["date"] = $dataDelivery["date"];
					$data["Colis"]["heure"] = $dataDelivery["heure"];

					$success = true;
					$msg = "";
				}else{
					$success = false;
					$msg = 'Le colis n\'existe pas.';
				}
			}
		}else{
			$success = false;
			$msg = "Il manque des informations";
		}

		$array['success'] = $success;
        $array['msg'] = $msg;
        $array['result'] = $data;

		header('Content-Type:Application/json'); 
		echo json_encode($array);
	}
}