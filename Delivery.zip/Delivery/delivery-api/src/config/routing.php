<?php
use App\Action\addPoint;
use App\Action\getPosition;

return [
    [
      'path' => '/delivery-api/colis/add',
      'method' => 'POST',
      'action' => addPoint::class
    ],
    [
      'path' => '/delivery-api/colis/get',
      'method' => 'GET',
      'action' => getPosition::class
    ],
];