<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Microservice Delivery</title>
        <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap(3.3.5).min.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <style type="text/css">
            #map{ /* la carte doit avoir une hauteur sinon elle n'apparaît pas */
                height:100%;
            }

            html, body {
                height: 100%;
                margin: 0;
                padding: 0;
            }
        </style>

        <script async type="text/javascript">

            var $_GET = <?php echo json_encode($_GET); ?>;

            // On initialise la latitude et la longitude de Nancy (centre de la carte)
            var LatCenter = 48.692054;
            var LongCenter = 6.184417;
            var map = null;

            // Fonction d'initialisation de la carte
            function initMap() {
                // Créer l'objet "map" et l'insérer dans l'élément HTML qui a l'ID "map"
                map = new google.maps.Map(document.getElementById("map"), {
                    // Nous plaçons le centre de la carte avec les coordonnées ci-dessus
                    center: new google.maps.LatLng(LatCenter, LongCenter),
                    // Nous définissons le zoom par défaut
                    zoom: 6,
                    // Nous définissons le type de carte (ici carte routière)
                    mapTypeId: google.maps.MapTypeId.ROADMAP,
                    // Nous activons les options de contrôle de la carte (plan, satellite...)
                    mapTypeControl: true,
                    // Nous activons la roulette de souris
                    scrollwheel: true,
                    mapTypeControlOptions: {
                        // Cette option sert à définir comment les options se placent
                        style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR
                    },
                    // Activation des options de navigation dans la carte (zoom...)
                    navigationControl: true,
                    navigationControlOptions: {
                        // Comment ces options doivent-elles s'afficher
                        style: google.maps.NavigationControlStyle.ZOOM_PAN
                    }
                });

                var geocoder = new google.maps.Geocoder();
                var infowindow = new google.maps.InfoWindow();
                axios.get('/lp/ProjetTutore/Delivery/delivery-api/public/index.php/delivery-api/colis/get?parcel_number=all')
                    .then(function (response) {
                        // handle success
                        //console.log(response); //Pour récupérer toutes les infos de connexion
                        //console.log(response.data.result.Colis);
                        var colis = response.data.result.Colis;

                        var deliveryData = document.getElementById('dataDelivery');

                        for (var i = 0; i < colis.length; i++) {
                            if ($_GET['parcel_number'] == colis[i].parcel_number) {

                                var translateRow = document.createElement('tr');
                                var numColis = document.createElement('td');
                                var latitude = document.createElement('td');
                                var longitude = document.createElement('td');
                                var date = document.createElement('td');
                                var heure = document.createElement('td');

                                numColis.textContent = colis[i].parcel_number;
                                latitude.textContent = colis[i].latitude;
                                longitude.textContent = colis[i].longitude;
                                date.textContent = colis[i].date;
                                heure.textContent = colis[i].heure;

                                deliveryData.appendChild(translateRow);
                                translateRow.appendChild(numColis);
                                translateRow.appendChild(latitude);
                                translateRow.appendChild(longitude);
                                translateRow.appendChild(date);
                                translateRow.appendChild(heure);

                                var Lat = colis[i].latitude;
                                var Long = colis[i].longitude;
                                var NumeroColis = colis[i].parcel_number;

                                // Conversion des strings récupérer de la bdd en float
                                Lat = parseFloat(Lat);
                                Long = parseFloat(Long);

                                var LatLong = {lat: Lat, lng: Long};

                                //Pour créer un marqueur sur la carte
                                var marker = new google.maps.Marker({
                                    position: LatLong,
                                    map: map,
                                    title: NumeroColis
                                });

                                // Création du message contenu dans l'infobulle
                                var InfoColis =
                                    '<div id="bodyContent">'+
                                    '<p><b>Numéro de colis : '+NumeroColis+'</b>'+
                                    '</div>'
                                ;
                                //Fonction permettant l'affichage des différents colis
                                attachInfoColis(marker, InfoColis[InfoColis]);

                                function attachInfoColis(marker, map) {
                                    var infowindow = new google.maps.InfoWindow({
                                        content: InfoColis
                                    });

                                    // Différents event sur les marqueurs
                                    //Ici au survol on aura la variable info declaré avant
                                    marker.addListener('mouseover', function () {
                                        infowindow.open(marker.get('map'), marker);
                                    });
                                    marker.addListener('mouseout', function () {
                                        infowindow.close(marker.get('map'), marker);
                                    });


                                    marker.addListener('click', function() {
                                        $(document).ready(function() {
                                            $('#ModalInfoColis').modal('show');
                                        });
                                    });
                                }
                            }
                        }
                    })
                    .catch(function (error) {
                        // handle error
                        console.log(error);
                    });

/*
                var Icon = {
                    // Adresse de l'icône personnalisée
                    url: Lien de l'icone voulue,
                    // Taille de l'icône personnalisée
                    size: new google.maps.Size(25, 40),
                    // Origine de l'image, souvent (0, 0)
                    origin: new google.maps.Point(0,0),
                    // L'ancre de l'image. Correspond au point de l'image que l'on raccroche à la carte
                    anchor: new google.maps.Point(17, 34)
                };*/
            }
        </script>
    </head>
    <body>

        <div id="map"></div>

        <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="ModalInfoColis">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Information du colis</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>N° de colis</th>
                                <th>Latitude</th>
                                <th>Longitude</th>
                                <th>Date</th>
                                <th>Heure</th>
                            </tr>
                            </thead>
                            <tbody id="dataDelivery">

                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Quitter</button>
                    </div>
                </div>
            </div>
        </div>

        <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAlJcCMN0pqwVHmJKGjHU0Ib9SmVLz6Hqo&callback=initMap" type="text/javascript">//</script>
    </body>
</html>