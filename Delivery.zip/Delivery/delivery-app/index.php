<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Microservice Delivery</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/bootstrap(3.3.5).min.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>
    <body>

        <form method="post" action="../delivery-client/examples/getPosition.php" id="formGetNumber">
            <input type="text" class="form-input" placeholder="Votre N° de colis" name="parcel_number" required>
        </form>
        <button type="submit" class="form-validate" form="formGetNumber">Valider</button>

        <!-- bouton de lancement du modal d'ajout -->
        <button type="button" class="form-add" data-toggle="modal" data-target="#addPoint">Ajouter une position</button>

        <!--Ajout d'une poisition -->
        <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="addPoint">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ajouter une position</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="post" id="formAddPoint" action="../delivery-client/examples/addPoint.php">
                            <div class="form-group">
                                <label for="recipient-name" class="col-form-label">N° de colis :</label>
                                <input type="text" class="form-control" id="recipient-name" name="parcel_number">
                            </div>
                            <div class="form-group">
                                <label for="message-text" class="col-form-label">Latitude :</label>
                                <input type="text" class="form-control" id="recipient-name" name="latitude">
                            </div>
                            <div class="form-group">
                                <label for="message-text" class="col-form-label">Longitude :</label>
                                <input type="text" class="form-control" id="recipient-name" name="longitude">
                            </div>
                            <div class="form-group">
                                <label for="message-text" class="col-form-label">Date :</label>
                                <input type="date" class="form-control" id="recipient-name" name="date">
                            </div>
                            <div class="form-group">
                                <label for="message-text" class="col-form-label">Heure :</label>
                                <input type="time" class="form-control" id="recipient-name" name="heure">
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary" form="formAddPoint">Sauvegarder</button>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>