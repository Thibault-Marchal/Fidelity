<?php
use App\Client\DeliveryClient;

require_once __DIR__ . '/../vendor/autoload.php';

$client = new DeliveryClient([
    'base_uri' => 'https://www.jordan-portfolio.dyjix.fr/'
]);
echo "\n\n";
echo $client->getPosition($_POST['parcel_number']);
echo "\n\n";
header('https://www.jordan-portfolio.dyjix.fr/projet/Delivery/delivery-app/map.php?parcel_number='.$_POST['parcel_number']);
