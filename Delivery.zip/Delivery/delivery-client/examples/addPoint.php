<?php
use App\Client\DeliveryClient;

require_once __DIR__ . '/../vendor/autoload.php';

$client = new DeliveryClient([
    'base_uri' => 'http://127.0.0.1/'
]);
echo "\n\n";
print_r($_POST);
echo $client->addPoint($_POST['parcel_number'], $_POST['latitude'], $_POST['longitude'], $_POST['date'], $_POST['heure']);
echo "\n\n";
header('Location: https://www.jordan-portfolio.dyjix.fr/projet/Delivery/delivery-app/index.php');
