<?php
namespace App\Client;

use GuzzleHttp\Client;

class DeliveryClient extends Client
{


    /**
     * @param string $parcel_number
     * @return string
     *
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function getPosition(string $parcel_number): string
    {
        $response = $this->request('POST', '/Projet/Delivery/delivery-api/public/index.php/delivery-api/colis/get?parcel_number=' . $parcel_number);

        $newsUrl = (string)$response->getBody();

        return $newsUrl;
    }

    /**
     * @param string $locale $key_trad $translation $nameApp
     * @param string $key_trad
     * @param string $translation
     * @param string $nameApp
     * @return string
     *
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function addPoint(int $parcel_number, float $latitude, float $longitude, string $date, string $heure): string
    {
        $response = $this->request('POST', '/Projet/Delivery/delivery-api/public/index.php/delivery-api/colis/add?parcel_number='. $parcel_number.'&latitude='. $latitude.'&longitude='. $longitude.'&date='. $date.'&heure='. $heure);

        $newsUrl = (string)$response->getBody();

        return $newsUrl;
    }

}