<?php
namespace App\Action;

use App\Manager\Card;

class decreasePoint
{
  public function __invoke($params)
  {
    $card = new Card();
    $dataFidelity = $card->decreasePoint($_GET['email'], $_GET['point']);

    return $dataFidelity;
  }
}