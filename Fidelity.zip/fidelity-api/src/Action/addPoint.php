<?php
namespace App\Action;

use App\Manager\Card;

class addPoint
{
  public function __invoke($params)
  {
    $card = new Card();
    $dataFidelity = $card->addPoint($_GET['email'], $_GET['point']);

    return $dataFidelity;
  }
}