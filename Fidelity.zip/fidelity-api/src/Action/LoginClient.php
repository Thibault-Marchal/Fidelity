<?php
namespace App\Action;

use App\Manager\Card;

class LoginClient
{
  public function __invoke($params)
  {
    $card = new Card();
    $dataFidelity = $card->LoginClient($_GET['email']);

    return $dataFidelity;
  }
}