<?php
use App\Action\addPoint;
use App\Action\decreasePoint;
use App\Action\LoginClient;

return [
    [
      'path' => '/fidelity-api/point/add',
      'method' => 'POST',
      'action' => addPoint::class
    ],
    [
      'path' => '/fidelity-api/point/decrease',
      'method' => 'POST',
      'action' => decreasePoint::class
    ],
    [
      'path' => '/fidelity-api/point/login',
      'method' => 'POST',
      'action' => LoginClient::class
    ],
];