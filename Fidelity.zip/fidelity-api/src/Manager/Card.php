<?php
namespace App\Manager;
use PDO;

/**
 * Class Card
 *
 * @package App\Manager
 */
class Card
{
    protected $email;
    protected $number;

    public function getEmail(){ 
        return $this->email; 
    }

    public function setEmail($email){ 
        $this->email = $email; 
    }

    public function getNumber(){ 
        return $this->number; 
    }
    
    public function setNumber($number){ 
        $this->number = $number; 
    }


    public function addPoint(string $email, int $number)
    {
        require './../src/include/connexion.php';
        if( !empty($email) && !empty($number)){

            // On vérifie si l'adresse mail existe
            $emailExistReq = $bdd->prepare('SELECT COUNT(*) AS emailExist FROM fidelity WHERE email = :email');
            $emailExistReq->execute(array(
                'email' => $email)); 
            $dataEmail = $emailExistReq->fetch(); 

            // Si l'email existe, on ajoute les points
            if (($dataEmail['emailExist'] == 1))
            {
                // On récupère tout du client
                $getPointReq = $bdd->prepare('SELECT * FROM fidelity WHERE email = :email');
                $getPointReq->execute(array(
                    'email' => $email)); 
                $data = array(); 

                $dataFidelity = $getPointReq->fetch(); 
                $getPointReq->closeCursor();

                $data["Fidelity"]["id"] = $dataFidelity["id"]; 
                $data["Fidelity"]["email"] = $dataFidelity["email"]; 
                $data["Fidelity"]["point"] = $dataFidelity["point"];

                $addPointReq = $bdd->prepare('UPDATE fidelity SET point =:point WHERE email=:email');
                $addPointReq->execute(array(
                    'point' => $dataFidelity["point"] + $number,
                    'email' => $email)); 

                if($addPointReq->execute()){
                    $success = true;
                    $msg = 'Points ajoutés';
                }else{
                    $success = false;
                    $msg = "Une erreur s'est produite";
                }
                $addPointReq->closeCursor();
            }else{
                $success = false;
                $msg = 'L\'adresse mail n\'existe pas dans la base de données.';
            }
        }else{
            $success = false;
            $msg = "Il manque des informations";
        }

        $array['success'] = $success;
        $array['msg'] = $msg;
        $array['points'] = $dataFidelity["point"] + $number;

        header('Content-Type:Application/json'); 
        echo json_encode($array);
    }

    public function decreasePoint(string $email, int $number)
    {
        require './../src/include/connexion.php';
        if( !empty($email) && !empty($number)){

            // On vérifie si l'adresse mail existe
            $emailExistReq = $bdd->prepare('SELECT COUNT(*) AS emailExist FROM fidelity WHERE email = :email');
            $emailExistReq->execute(array(
                'email' => $email)); 
            $dataEmail = $emailExistReq->fetch(); 

            // Si l'email exist, on ajoute les points
            if (($dataEmail['emailExist'] == 1))
            {
                // On récupère tout du client
                $getPointReq = $bdd->prepare('SELECT * FROM fidelity WHERE email = :email');
                $getPointReq->execute(array(
                    'email' => $email)); 
                $data = array(); 

                $dataFidelity = $getPointReq->fetch(); 

                $data["Fidelity"]["id"] = $dataFidelity["id"]; 
                $data["Fidelity"]["email"] = $dataFidelity["email"]; 
                $data["Fidelity"]["point"] = $dataFidelity["point"];
                // Fin de la récupération

                if($data["Fidelity"]["point"] - $number >= 0){
                    $addPointReq = $bdd->prepare('UPDATE fidelity SET point =:point WHERE email=:email');
                    $addPointReq->execute(array(
                        'point' => $dataFidelity["point"] - $number,
                        'email' => $email));

                    if( $addPointReq->execute() ){
                        $success = true;
                        $msg = 'Points supprimés';
                    }else{
                        $success = false;
                        $msg = "Une erreur s'est produite";
                    }
                    $addPointReq->closeCursor();
                }else{
                    $success = false;
                    $msg = 'Impossible d\'acheter ce produit. (Vous n\'avez que ' . $data["Fidelity"]["point"] .' points)';
                }  
            }else{
                $success = false;
                $msg = 'L\'adresse mail n\'existe pas dans la base de données.';
            }
        }else{
            $success = false;
            $msg = "Il manque des informations";
        }

        $array['success'] = $success;
        $array['msg'] = $msg;
        $array['points'] = $dataFidelity["point"] - $number;

        header('Content-Type:Application/json'); 
        echo json_encode($array);
    }


    public function LoginClient(string $email){
        require './../src/include/connexion.php';
        if(!empty($email)){

            // On vérifie si l'adresse mail existe
            $emailExistReq = $bdd->prepare('SELECT COUNT(*) AS emailExist FROM fidelity WHERE email = :email');
            $emailExistReq->execute(array(
                'email' => $email)); 
            $dataEmail = $emailExistReq->fetch(); 


            // On récupère tout du client
            $getPointReq = $bdd->prepare('SELECT * FROM fidelity WHERE email = :email');
            $getPointReq->execute(array(
                'email' => $email)); 
            $data = array(); 

            $dataFidelity = $getPointReq->fetch(); 

            $email =  $dataFidelity["email"]; 
            $points = $dataFidelity["point"];
            // Fin de la récupération

            if (($dataEmail['emailExist'] == 1)){
                $success = true;
                $msg = 'Client connu';
            }else{
                $success = false;
                $msg = "Client inconnu";
            }
        }else{
            $success = false;
            $msg = "Il manque des informations";
        }

        $array['success'] = $success;
        $array['msg'] = $msg;
        $array['email'] = $email;
        $array['points'] = $points;

        header('Content-Type:Application/json'); 
        echo json_encode($array);
    }
}