function addPoints(points){
    fetch('https://www.jordan-portfolio.dyjix.fr/projet/Fidelity/fidelity-api/public/index.php/fidelity-api/point/add?'
        + new URLSearchParams(
            {
                email: localStorage.getItem('email'),
                point: points}
            ),
        {
            method: "POST"
        })
    .then(response => response.json())
    .then(function(response) {
		if(response.success == true){
           alert('Vous avez ajouté 100 points à votre compte.');
            localStorage.setItem('points', response.points);
		}else{
			alert("Erreur lors de l'ajout des points");
		}
    })
    .catch(error => alert("Erreur : " + error));
}

