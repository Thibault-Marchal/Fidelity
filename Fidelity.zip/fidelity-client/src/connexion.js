function login(){
	fetch('https://www.jordan-portfolio.dyjix.fr/projet/Fidelity/fidelity-api/public/index.php/fidelity-api/point/login?'
		+ new URLSearchParams(
			{email: email.value}
			),
		{
			method: "POST"
		})
	.then(response => response.json())
	.then(function(response) {
      if(response.success == true){
      		localStorage.setItem('email', response.email);
      		localStorage.setItem('points', response.points);
			//console.log(response);
			document.location.href="products.html"
		} else {
			alert('Utilisateur inconnu');
		}
	})
	.catch(error => alert("Erreur : " + error));
}