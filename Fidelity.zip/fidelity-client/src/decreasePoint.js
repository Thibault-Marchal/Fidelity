function decreasePoint(id,point){
    fetch('https://www.jordan-portfolio.dyjix.fr/projet/Fidelity/fidelity-api/public/index.php/fidelity-api/point/decrease?'
        + new URLSearchParams(
            {
                email: localStorage.getItem('email'),
                point: point}
            ),
        {
            method: "POST"
        })
    .then(response => response.json())
    .then(function(response) {
        if(response.success == true){
            alert('Produit n°' + id + ' acheté. (Vous avez dépensé ' + point + ' points.)');
            localStorage.setItem('points', response.points);
        } else {
            alert(response.msg);
        }
    })
    .catch(error => alert("Erreur : " + error));
}

